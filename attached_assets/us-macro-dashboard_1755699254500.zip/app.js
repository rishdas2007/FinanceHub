// US Macroeconomic Dashboard JavaScript

// Bloomberg Terminal Color Scheme
const bloombergColors = {
    cyan: '#00d4ff',
    orange: '#ff8c00',
    green: '#00ff00',
    red: '#ff4444',
    white: '#ffffff',
    text: '#e0e0e0',
    textDim: '#a0a0a0',
    background: '#000000',
    surface: '#1a1a1a',
    border: '#2a2a2a'
};

// Chart.js default configuration
Chart.defaults.color = bloombergColors.text;
Chart.defaults.borderColor = bloombergColors.border;
Chart.defaults.backgroundColor = bloombergColors.surface;

// Economic data
const economicData = {
    gdp: {
        quarters: ["Q2 2024", "Q3 2024", "Q4 2024", "Q1 2025", "Q2 2025"],
        realGrowth: [2.0, 3.1, 2.4, -0.5, 3.0],
        nominalGdp: [29.0, 29.4, 29.7, 30.0, 30.3]
    },
    inflation: {
        months: ["Mar 2025", "Apr 2025", "May 2025", "Jun 2025"],
        headlinePce: [2.3, 2.2, 2.4, 2.6],
        corePce: [2.7, 2.6, 2.8, 2.8],
        fedTarget: [2.0, 2.0, 2.0, 2.0]
    },
    labor: {
        months: ["May 2025", "Jun 2025", "Jul 2025"],
        unemployment: [4.2, 4.1, 4.2],
        participation: [62.4, 62.3, 62.2],
        employmentRatio: [59.7, 59.7, 59.6]
    },
    trade: {
        months: ["Apr 2025", "May 2025", "Jun 2025"],
        deficit: [-97.3, -71.7, -60.2],
        exports: [171.9, 278.7, 277.3],
        imports: [269.2, 350.3, 337.5]
    }
};

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    initializeTabs();
    updateDateTime();
    createCharts();
    
    // Update time every minute
    setInterval(updateDateTime, 60000);
});

// Tab functionality
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetTab = this.dataset.tab;
            
            // Remove active class from all buttons and panes
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabPanes.forEach(pane => pane.classList.remove('active'));
            
            // Add active class to clicked button and corresponding pane
            this.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
        });
    });
}

// Update date and time
function updateDateTime() {
    const now = new Date();
    const options = { 
        weekday: 'short', 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZoneName: 'short'
    };
    
    const dateTimeString = now.toLocaleDateString('en-US', options);
    const dateTimeElement = document.getElementById('current-date');
    if (dateTimeElement) {
        dateTimeElement.textContent = dateTimeString;
    }
}

// Create all charts
function createCharts() {
    createNominalGdpChart();
    createRealGdpChart();
    createInflationChart();
    createLaborChart();
    createTradeChart();
}

// Nominal GDP Chart
function createNominalGdpChart() {
    const ctx = document.getElementById('nominalGdpChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: economicData.gdp.quarters,
            datasets: [{
                label: 'Nominal GDP ($ Trillions)',
                data: economicData.gdp.nominalGdp,
                borderColor: bloombergColors.cyan,
                backgroundColor: bloombergColors.cyan + '20',
                borderWidth: 2,
                fill: false,
                pointBackgroundColor: bloombergColors.cyan,
                pointBorderColor: bloombergColors.cyan,
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Nominal GDP ($ Trillions)',
                    color: bloombergColors.orange,
                    font: {
                        size: 14,
                        weight: 'bold',
                        family: 'Courier New'
                    }
                },
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    grid: {
                        color: bloombergColors.border
                    },
                    ticks: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 11
                        }
                    }
                },
                y: {
                    grid: {
                        color: bloombergColors.border
                    },
                    ticks: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 11
                        },
                        callback: function(value) {
                            return '$' + value + 'T';
                        }
                    }
                }
            }
        }
    });
}

// Real GDP Growth Chart
function createRealGdpChart() {
    const ctx = document.getElementById('realGdpChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: economicData.gdp.quarters,
            datasets: [{
                label: 'Real GDP Growth (%)',
                data: economicData.gdp.realGrowth,
                backgroundColor: economicData.gdp.realGrowth.map(value => 
                    value >= 0 ? bloombergColors.green + '80' : bloombergColors.red + '80'
                ),
                borderColor: economicData.gdp.realGrowth.map(value => 
                    value >= 0 ? bloombergColors.green : bloombergColors.red
                ),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Real GDP Growth (%)',
                    color: bloombergColors.orange,
                    font: {
                        size: 14,
                        weight: 'bold',
                        family: 'Courier New'
                    }
                },
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    grid: {
                        color: bloombergColors.border
                    },
                    ticks: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 11
                        }
                    }
                },
                y: {
                    grid: {
                        color: bloombergColors.border
                    },
                    ticks: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 11
                        },
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
}

// Inflation Chart
function createInflationChart() {
    const ctx = document.getElementById('inflationChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: economicData.inflation.months,
            datasets: [
                {
                    label: 'Headline PCE',
                    data: economicData.inflation.headlinePce,
                    borderColor: bloombergColors.cyan,
                    backgroundColor: bloombergColors.cyan + '20',
                    borderWidth: 2,
                    fill: false,
                    pointBackgroundColor: bloombergColors.cyan,
                    pointBorderColor: bloombergColors.cyan,
                    pointRadius: 4
                },
                {
                    label: 'Core PCE',
                    data: economicData.inflation.corePce,
                    borderColor: bloombergColors.orange,
                    backgroundColor: bloombergColors.orange + '20',
                    borderWidth: 2,
                    fill: false,
                    pointBackgroundColor: bloombergColors.orange,
                    pointBorderColor: bloombergColors.orange,
                    pointRadius: 4
                },
                {
                    label: 'Fed Target',
                    data: economicData.inflation.fedTarget,
                    borderColor: bloombergColors.red,
                    backgroundColor: bloombergColors.red + '20',
                    borderWidth: 2,
                    borderDash: [5, 5],
                    fill: false,
                    pointBackgroundColor: bloombergColors.red,
                    pointBorderColor: bloombergColors.red,
                    pointRadius: 3
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Inflation Trends (% YoY)',
                    color: bloombergColors.orange,
                    font: {
                        size: 14,
                        weight: 'bold',
                        family: 'Courier New'
                    }
                },
                legend: {
                    display: true,
                    labels: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 11
                        },
                        usePointStyle: true
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: bloombergColors.border
                    },
                    ticks: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 11
                        }
                    }
                },
                y: {
                    grid: {
                        color: bloombergColors.border
                    },
                    ticks: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 11
                        },
                        callback: function(value) {
                            return value.toFixed(1) + '%';
                        }
                    }
                }
            }
        }
    });
}

// Labor Market Chart
function createLaborChart() {
    const ctx = document.getElementById('laborChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: economicData.labor.months,
            datasets: [
                {
                    label: 'Unemployment Rate',
                    data: economicData.labor.unemployment,
                    borderColor: bloombergColors.red,
                    backgroundColor: bloombergColors.red + '20',
                    borderWidth: 2,
                    fill: false,
                    pointBackgroundColor: bloombergColors.red,
                    pointBorderColor: bloombergColors.red,
                    pointRadius: 4,
                    yAxisID: 'y'
                },
                {
                    label: 'Labor Force Participation',
                    data: economicData.labor.participation,
                    borderColor: bloombergColors.cyan,
                    backgroundColor: bloombergColors.cyan + '20',
                    borderWidth: 2,
                    fill: false,
                    pointBackgroundColor: bloombergColors.cyan,
                    pointBorderColor: bloombergColors.cyan,
                    pointRadius: 4,
                    yAxisID: 'y1'
                },
                {
                    label: 'Employment-Population Ratio',
                    data: economicData.labor.employmentRatio,
                    borderColor: bloombergColors.orange,
                    backgroundColor: bloombergColors.orange + '20',
                    borderWidth: 2,
                    fill: false,
                    pointBackgroundColor: bloombergColors.orange,
                    pointBorderColor: bloombergColors.orange,
                    pointRadius: 4,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Labor Market Indicators',
                    color: bloombergColors.orange,
                    font: {
                        size: 14,
                        weight: 'bold',
                        family: 'Courier New'
                    }
                },
                legend: {
                    display: true,
                    labels: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 10
                        },
                        usePointStyle: true
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: bloombergColors.border
                    },
                    ticks: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 11
                        }
                    }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    min: 3.5,
                    max: 4.5,
                    grid: {
                        color: bloombergColors.border
                    },
                    ticks: {
                        color: bloombergColors.red,
                        font: {
                            family: 'Courier New',
                            size: 11
                        },
                        callback: function(value) {
                            return value.toFixed(1) + '%';
                        }
                    },
                    title: {
                        display: true,
                        text: 'Unemployment Rate (%)',
                        color: bloombergColors.red,
                        font: {
                            family: 'Courier New',
                            size: 10
                        }
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    min: 59,
                    max: 63,
                    grid: {
                        drawOnChartArea: false,
                    },
                    ticks: {
                        color: bloombergColors.cyan,
                        font: {
                            family: 'Courier New',
                            size: 11
                        },
                        callback: function(value) {
                            return value.toFixed(1) + '%';
                        }
                    },
                    title: {
                        display: true,
                        text: 'Participation & Employment (%)',
                        color: bloombergColors.cyan,
                        font: {
                            family: 'Courier New',
                            size: 10
                        }
                    }
                }
            }
        }
    });
}

// Trade Balance Chart
function createTradeChart() {
    const ctx = document.getElementById('tradeChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: economicData.trade.months,
            datasets: [
                {
                    label: 'Trade Deficit',
                    data: economicData.trade.deficit,
                    borderColor: bloombergColors.red,
                    backgroundColor: bloombergColors.red + '20',
                    borderWidth: 3,
                    fill: true,
                    pointBackgroundColor: bloombergColors.red,
                    pointBorderColor: bloombergColors.red,
                    pointRadius: 5,
                    yAxisID: 'y'
                },
                {
                    label: 'Exports',
                    data: economicData.trade.exports,
                    borderColor: bloombergColors.green,
                    backgroundColor: bloombergColors.green + '20',
                    borderWidth: 2,
                    fill: false,
                    pointBackgroundColor: bloombergColors.green,
                    pointBorderColor: bloombergColors.green,
                    pointRadius: 4,
                    yAxisID: 'y1'
                },
                {
                    label: 'Imports',
                    data: economicData.trade.imports,
                    borderColor: bloombergColors.orange,
                    backgroundColor: bloombergColors.orange + '20',
                    borderWidth: 2,
                    fill: false,
                    pointBackgroundColor: bloombergColors.orange,
                    pointBorderColor: bloombergColors.orange,
                    pointRadius: 4,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Trade Balance & Flows ($ Billions)',
                    color: bloombergColors.orange,
                    font: {
                        size: 14,
                        weight: 'bold',
                        family: 'Courier New'
                    }
                },
                legend: {
                    display: true,
                    labels: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 11
                        },
                        usePointStyle: true
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: bloombergColors.border
                    },
                    ticks: {
                        color: bloombergColors.text,
                        font: {
                            family: 'Courier New',
                            size: 11
                        }
                    }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    min: -120,
                    max: 0,
                    grid: {
                        color: bloombergColors.border
                    },
                    ticks: {
                        color: bloombergColors.red,
                        font: {
                            family: 'Courier New',
                            size: 11
                        },
                        callback: function(value) {
                            return '$' + value + 'B';
                        }
                    },
                    title: {
                        display: true,
                        text: 'Trade Deficit ($B)',
                        color: bloombergColors.red,
                        font: {
                            family: 'Courier New',
                            size: 10
                        }
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    min: 150,
                    max: 400,
                    grid: {
                        drawOnChartArea: false,
                    },
                    ticks: {
                        color: bloombergColors.green,
                        font: {
                            family: 'Courier New',
                            size: 11
                        },
                        callback: function(value) {
                            return '$' + value + 'B';
                        }
                    },
                    title: {
                        display: true,
                        text: 'Exports/Imports ($B)',
                        color: bloombergColors.green,
                        font: {
                            family: 'Courier New',
                            size: 10
                        }
                    }
                }
            }
        }
    });
}