// Database connection export
// Re-exports the main database connection for compatibility with existing imports
export { db, pool } from '../db';