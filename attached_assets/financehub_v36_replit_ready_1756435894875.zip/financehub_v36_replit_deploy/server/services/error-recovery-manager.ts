/**
 * Error Recovery Manager - Centralized Error Handling & Recovery
 * 
 * Provides:
 * - Circuit breaker pattern for external APIs
 * - Graceful degradation strategies
 * - Connection pool recovery
 * - Service health monitoring
 * - Automatic retry with exponential backoff
 */

import { logger } from '../utils/logger';
import { unifiedCache } from './cache-manager-unified';

interface CircuitBreakerConfig {
  failureThreshold: number;
  timeout: number;
  retryDelay: number;
  maxRetries: number;
}

interface ServiceHealth {
  serviceName: string;
  status: 'healthy' | 'degraded' | 'unhealthy';
  lastCheck: Date;
  failures: number;
  successes: number;
  avgResponseTime: number;
}

class CircuitBreaker {
  private failures = 0;
  private lastFailure?: Date;
  private state: 'closed' | 'open' | 'half-open' = 'closed';

  constructor(
    private serviceName: string,
    private config: CircuitBreakerConfig
  ) {}

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure!.getTime() > this.config.timeout) {
        this.state = 'half-open';
      } else {
        throw new Error(`Circuit breaker open for ${this.serviceName}`);
      }
    }

    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess(): void {
    this.failures = 0;
    this.state = 'closed';
    logger.debug(`Circuit breaker success for ${this.serviceName}`);
  }

  private onFailure(): void {
    this.failures++;
    this.lastFailure = new Date();
    
    if (this.failures >= this.config.failureThreshold) {
      this.state = 'open';
      logger.warn(`Circuit breaker opened for ${this.serviceName} after ${this.failures} failures`);
    }
  }

  getState(): string {
    return this.state;
  }

  getFailures(): number {
    return this.failures;
  }
}

export class ErrorRecoveryManager {
  private static instance: ErrorRecoveryManager;
  private circuitBreakers = new Map<string, CircuitBreaker>();
  private serviceHealth = new Map<string, ServiceHealth>();
  private retryQueue: Array<{
    key: string;
    operation: () => Promise<any>;
    retries: number;
    maxRetries: number;
    delay: number;
  }> = [];

  private readonly configs: Record<string, CircuitBreakerConfig> = {
    'twelve-data-api': {
      failureThreshold: 5,
      timeout: 60000,
      retryDelay: 2000,
      maxRetries: 3
    },
    'fred-api': {
      failureThreshold: 3,
      timeout: 120000,
      retryDelay: 5000,
      maxRetries: 2
    },
    'database': {
      failureThreshold: 3,
      timeout: 30000,
      retryDelay: 1000,
      maxRetries: 5
    },
    'internal-api': {
      failureThreshold: 5,
      timeout: 30000,
      retryDelay: 1000,
      maxRetries: 3
    }
  };

  private constructor() {
    // Initialize circuit breakers
    Object.keys(this.configs).forEach(service => {
      this.circuitBreakers.set(
        service,
        new CircuitBreaker(service, this.configs[service])
      );
      
      this.serviceHealth.set(service, {
        serviceName: service,
        status: 'healthy',
        lastCheck: new Date(),
        failures: 0,
        successes: 0,
        avgResponseTime: 0
      });
    });

    // Process retry queue every 5 seconds
    setInterval(() => this.processRetryQueue(), 5000);
    
    // Health check every 30 seconds
    setInterval(() => this.updateServiceHealth(), 30000);

    logger.info('🛡️ Error Recovery Manager initialized');
  }

  static getInstance(): ErrorRecoveryManager {
    if (!ErrorRecoveryManager.instance) {
      ErrorRecoveryManager.instance = new ErrorRecoveryManager();
    }
    return ErrorRecoveryManager.instance;
  }

  /**
   * Execute operation with circuit breaker protection
   */
  async executeWithCircuitBreaker<T>(
    serviceName: string,
    operation: () => Promise<T>,
    fallback?: () => Promise<T>
  ): Promise<T> {
    const circuitBreaker = this.getOrCreateCircuitBreaker(serviceName);
    const startTime = Date.now();

    try {
      const result = await circuitBreaker.execute(operation);
      this.recordSuccess(serviceName, Date.now() - startTime);
      return result;
    } catch (error) {
      this.recordFailure(serviceName, error as Error);
      
      // Try fallback if available
      if (fallback) {
        logger.warn(`Using fallback for ${serviceName}: ${(error as Error).message}`);
        try {
          return await fallback();
        } catch (fallbackError) {
          logger.error(`Fallback failed for ${serviceName}:`, fallbackError);
          throw error; // Throw original error
        }
      }
      
      throw error;
    }
  }

  /**
   * Execute operation with retry logic
   */
  async executeWithRetry<T>(
    key: string,
    operation: () => Promise<T>,
    maxRetries: number = 3,
    initialDelay: number = 1000,
    backoffMultiplier: number = 2
  ): Promise<T> {
    let lastError: Error;
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        
        if (attempt < maxRetries) {
          const delay = initialDelay * Math.pow(backoffMultiplier, attempt);
          logger.warn(`Retry ${attempt + 1}/${maxRetries} for ${key} in ${delay}ms: ${lastError.message}`);
          await this.delay(delay);
        }
      }
    }

    logger.error(`All retries exhausted for ${key}:`, lastError!);
    throw lastError!;
  }

  /**
   * Get cached data with fallback strategy
   */
  async getWithFallback<T>(
    cacheKey: string,
    primaryOperation: () => Promise<T>,
    fallbackOperation?: () => Promise<T>,
    serviceName: string = 'internal-api'
  ): Promise<T> {
    // Check cache first
    const cached = unifiedCache.get<T>(cacheKey);
    if (cached) {
      return cached;
    }

    try {
      // Try primary operation with circuit breaker
      const result = await this.executeWithCircuitBreaker(
        serviceName,
        primaryOperation,
        fallbackOperation
      );
      
      // Cache successful result
      unifiedCache.set(cacheKey, result);
      return result;
      
    } catch (error) {
      logger.error(`Failed to get data for ${cacheKey}:`, error);
      
      // Return stale cache if available
      const staleCache = unifiedCache.get<T>(`${cacheKey}_stale`);
      if (staleCache) {
        logger.warn(`Using stale cache for ${cacheKey}`);
        return staleCache;
      }
      
      throw error;
    }
  }

  /**
   * Queue operation for retry
   */
  queueForRetry(
    key: string,
    operation: () => Promise<any>,
    maxRetries: number = 3,
    delay: number = 5000
  ): void {
    this.retryQueue.push({
      key,
      operation,
      retries: 0,
      maxRetries,
      delay
    });
    
    logger.info(`Queued ${key} for retry`);
  }

  /**
   * Get service health status
   */
  getServiceHealth(serviceName?: string): ServiceHealth[] | ServiceHealth | null {
    if (serviceName) {
      return this.serviceHealth.get(serviceName) || null;
    }
    return Array.from(this.serviceHealth.values());
  }

  /**
   * Get circuit breaker status
   */
  getCircuitBreakerStatus(): Array<{
    serviceName: string;
    state: string;
    failures: number;
  }> {
    return Array.from(this.circuitBreakers.entries()).map(([name, cb]) => ({
      serviceName: name,
      state: cb.getState(),
      failures: cb.getFailures()
    }));
  }

  /**
   * Reset circuit breaker for service
   */
  resetCircuitBreaker(serviceName: string): void {
    const config = this.configs[serviceName];
    if (config) {
      this.circuitBreakers.set(serviceName, new CircuitBreaker(serviceName, config));
      logger.info(`Circuit breaker reset for ${serviceName}`);
    }
  }

  /**
   * Get overall system health
   */
  getSystemHealth(): {
    status: 'healthy' | 'degraded' | 'unhealthy';
    services: ServiceHealth[];
    circuitBreakers: Array<{ serviceName: string; state: string }>;
  } {
    const services = Array.from(this.serviceHealth.values());
    const unhealthyCount = services.filter(s => s.status === 'unhealthy').length;
    const degradedCount = services.filter(s => s.status === 'degraded').length;
    
    let status: 'healthy' | 'degraded' | 'unhealthy';
    if (unhealthyCount > 0) {
      status = 'unhealthy';
    } else if (degradedCount > 0) {
      status = 'degraded';
    } else {
      status = 'healthy';
    }

    return {
      status,
      services,
      circuitBreakers: Array.from(this.circuitBreakers.entries()).map(([name, cb]) => ({
        serviceName: name,
        state: cb.getState()
      }))
    };
  }

  private getOrCreateCircuitBreaker(serviceName: string): CircuitBreaker {
    if (!this.circuitBreakers.has(serviceName)) {
      const config = this.configs[serviceName] || this.configs['internal-api'];
      this.circuitBreakers.set(serviceName, new CircuitBreaker(serviceName, config));
    }
    return this.circuitBreakers.get(serviceName)!;
  }

  private recordSuccess(serviceName: string, responseTime: number): void {
    const health = this.serviceHealth.get(serviceName);
    if (health) {
      health.successes++;
      health.lastCheck = new Date();
      health.avgResponseTime = (health.avgResponseTime + responseTime) / 2;
      
      // Improve status if consistently successful
      if (health.successes > 5 && health.failures === 0) {
        health.status = 'healthy';
      }
    }
  }

  private recordFailure(serviceName: string, error: Error): void {
    const health = this.serviceHealth.get(serviceName);
    if (health) {
      health.failures++;
      health.lastCheck = new Date();
      
      // Degrade status based on failure rate
      const totalRequests = health.successes + health.failures;
      const failureRate = health.failures / totalRequests;
      
      if (failureRate > 0.5) {
        health.status = 'unhealthy';
      } else if (failureRate > 0.2) {
        health.status = 'degraded';
      }
    }

    logger.error(`Service failure for ${serviceName}:`, error.message);
  }

  private async processRetryQueue(): Promise<void> {
    if (this.retryQueue.length === 0) return;

    const toProcess = this.retryQueue.splice(0, 5); // Process max 5 at a time
    
    for (const item of toProcess) {
      try {
        await item.operation();
        logger.info(`Retry successful for ${item.key}`);
      } catch (error) {
        item.retries++;
        
        if (item.retries < item.maxRetries) {
          // Re-queue with exponential backoff
          item.delay = Math.min(item.delay * 2, 30000);
          this.retryQueue.push(item);
          logger.warn(`Retry ${item.retries}/${item.maxRetries} failed for ${item.key}, re-queued`);
        } else {
          logger.error(`Retry exhausted for ${item.key}:`, error);
        }
      }
    }
  }

  private updateServiceHealth(): void {
    // Reset counters periodically to prevent accumulation
    for (const health of this.serviceHealth.values()) {
      if (Date.now() - health.lastCheck.getTime() > 300000) { // 5 minutes
        health.failures = Math.max(0, health.failures - 1);
        health.successes = Math.max(0, health.successes - 1);
      }
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Export singleton instance
export const errorRecoveryManager = ErrorRecoveryManager.getInstance();