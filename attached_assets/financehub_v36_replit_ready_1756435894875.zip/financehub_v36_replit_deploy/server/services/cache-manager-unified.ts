/**
 * Unified Cache Manager - Single Source of Truth for All Caching
 * 
 * Consolidates functionality from:
 * - cache-unified.ts
 * - intelligent-cache-system.ts 
 * - etf-cache-service-robust.ts
 * - unified-dashboard-cache.ts
 * - cache-performance-monitor.ts
 */

import { logger } from '../utils/logger';

interface CacheEntry<T> {
  data: T;
  timestamp: Date;
  ttl: number;
  hits: number;
  lastAccessed: Date;
  source: string;
}

interface CacheStats {
  totalEntries: number;
  totalHits: number;
  totalMisses: number;
  hitRate: number;
  memoryUsage: number;
  oldestEntry: Date | null;
}

interface CacheConfig {
  // Reduced TTLs to prevent stale data
  economic: number;        // 6 hours (down from 48 hours)
  etfMetrics: number;      // 5 minutes
  marketData: number;      // 2 minutes
  userSessions: number;    // 1 hour
  default: number;         // 15 minutes
}

export class UnifiedCacheManager {
  private static instance: UnifiedCacheManager;
  private memoryCache = new Map<string, CacheEntry<any>>();
  private stats = {
    hits: 0,
    misses: 0,
    sets: 0,
    deletes: 0
  };

  // Optimized TTL configuration
  private readonly config: CacheConfig = {
    economic: 6 * 60 * 60 * 1000,      // 6 hours - prevent stale economic data
    etfMetrics: 5 * 60 * 1000,         // 5 minutes - fresh market data
    marketData: 2 * 60 * 1000,         // 2 minutes - real-time data
    userSessions: 60 * 60 * 1000,      // 1 hour - user state
    default: 15 * 60 * 1000            // 15 minutes - general cache
  };

  private constructor() {
    // Cleanup expired entries every 5 minutes
    setInterval(() => this.cleanup(), 5 * 60 * 1000);
    
    // Memory monitoring every 30 seconds
    setInterval(() => this.monitorMemoryUsage(), 30 * 1000);
    
    logger.info('🚀 Unified Cache Manager initialized');
  }

  static getInstance(): UnifiedCacheManager {
    if (!UnifiedCacheManager.instance) {
      UnifiedCacheManager.instance = new UnifiedCacheManager();
    }
    return UnifiedCacheManager.instance;
  }

  /**
   * Get cached data with automatic TTL detection
   */
  get<T>(key: string): T | null {
    const entry = this.memoryCache.get(key);
    
    if (!entry) {
      this.stats.misses++;
      logger.debug(`Cache miss: ${key}`);
      return null;
    }

    const now = Date.now();
    
    // Check if expired
    if (now - entry.timestamp.getTime() > entry.ttl) {
      this.memoryCache.delete(key);
      this.stats.misses++;
      logger.debug(`Cache expired: ${key}`);
      return null;
    }

    // Update access stats
    entry.hits++;
    entry.lastAccessed = new Date();
    this.stats.hits++;
    
    logger.debug(`Cache hit: ${key} (${entry.hits} total hits)`);
    return entry.data as T;
  }

  /**
   * Set cached data with intelligent TTL selection
   */
  set<T>(key: string, data: T, customTtl?: number): void {
    const ttl = customTtl || this.getTtlForKey(key);
    const now = new Date();
    
    const entry: CacheEntry<T> = {
      data,
      timestamp: now,
      ttl,
      hits: 0,
      lastAccessed: now,
      source: this.getSourceFromKey(key)
    };

    this.memoryCache.set(key, entry);
    this.stats.sets++;
    
    logger.debug(`Cache set: ${key} (TTL: ${ttl}ms)`);

    // Prevent memory overflow
    if (this.memoryCache.size > 1000) {
      this.evictLeastUsed();
    }
  }

  /**
   * Get or compute and cache data
   */
  async getOrSet<T>(
    key: string,
    factory: () => Promise<T>,
    customTtl?: number
  ): Promise<T> {
    const cached = this.get<T>(key);
    if (cached !== null) {
      return cached;
    }

    try {
      const data = await factory();
      this.set(key, data, customTtl);
      return data;
    } catch (error) {
      logger.error(`Cache factory failed for ${key}:`, error);
      throw error;
    }
  }

  /**
   * Delete specific cache entry
   */
  delete(key: string): boolean {
    const deleted = this.memoryCache.delete(key);
    if (deleted) {
      this.stats.deletes++;
      logger.debug(`Cache delete: ${key}`);
    }
    return deleted;
  }

  /**
   * Clear cache by pattern
   */
  deleteByPattern(pattern: RegExp): number {
    let deleted = 0;
    
    for (const key of Array.from(this.memoryCache.keys())) {
      if (pattern.test(key)) {
        if (this.delete(key)) {
          deleted++;
        }
      }
    }
    
    logger.info(`Cache pattern delete: ${deleted} entries removed`);
    return deleted;
  }

  /**
   * Clear all cache
   */
  clear(): void {
    const size = this.memoryCache.size;
    this.memoryCache.clear();
    logger.info(`Cache cleared: ${size} entries removed`);
  }

  /**
   * Get comprehensive cache statistics
   */
  getStats(): CacheStats {
    const now = new Date();
    let memoryUsage = 0;
    let oldest = now;
    let newest = new Date(0);

    for (const [key, entry] of Array.from(this.memoryCache.entries())) {
      // Estimate memory usage
      memoryUsage += JSON.stringify(entry.data).length + key.length + 200;
      
      if (entry.timestamp < oldest) oldest = entry.timestamp;
      if (entry.timestamp > newest) newest = entry.timestamp;
    }

    const totalRequests = this.stats.hits + this.stats.misses;
    
    return {
      totalEntries: this.memoryCache.size,
      totalHits: this.stats.hits,
      totalMisses: this.stats.misses,
      hitRate: totalRequests > 0 ? (this.stats.hits / totalRequests) * 100 : 0,
      memoryUsage,
      oldestEntry: oldest === now ? null : oldest
    };
  }

  /**
   * Health check for cache system
   */
  async healthCheck(): Promise<{ healthy: boolean; details: string[] }> {
    const stats = this.getStats();
    const details: string[] = [];
    let healthy = true;

    // Check hit rate
    if (stats.hitRate < 60) {
      details.push(`Low cache hit rate: ${stats.hitRate.toFixed(1)}%`);
      healthy = false;
    }

    // Check memory usage (50MB threshold)
    const memoryMB = stats.memoryUsage / 1024 / 1024;
    if (memoryMB > 50) {
      details.push(`High memory usage: ${memoryMB.toFixed(1)}MB`);
      healthy = false;
    }

    // Check entry count
    if (stats.totalEntries > 900) {
      details.push(`High entry count: ${stats.totalEntries}`);
    }

    if (healthy) {
      details.push('Cache operating normally');
    }

    return { healthy, details };
  }

  /**
   * Intelligent TTL selection based on key pattern
   */
  private getTtlForKey(key: string): number {
    if (key.includes('economic') || key.includes('fred')) {
      return this.config.economic;
    }
    if (key.includes('etf') || key.includes('stock')) {
      return this.config.etfMetrics;
    }
    if (key.includes('market') || key.includes('quote')) {
      return this.config.marketData;
    }
    if (key.includes('session') || key.includes('user')) {
      return this.config.userSessions;
    }
    return this.config.default;
  }

  /**
   * Get data source from key
   */
  private getSourceFromKey(key: string): string {
    if (key.includes('fred') || key.includes('economic')) return 'FRED_API';
    if (key.includes('twelve') || key.includes('stock')) return 'TWELVE_DATA_API';
    if (key.includes('etf') || key.includes('sector')) return 'ETF_DATA';
    return 'INTERNAL';
  }

  /**
   * Clean up expired entries
   */
  private cleanup(): void {
    const now = Date.now();
    let expired = 0;
    
    for (const [key, entry] of Array.from(this.memoryCache.entries())) {
      if (now - entry.timestamp.getTime() > entry.ttl) {
        this.memoryCache.delete(key);
        expired++;
      }
    }
    
    if (expired > 0) {
      logger.info(`Cache cleanup: ${expired} expired entries removed`);
    }
  }

  /**
   * Evict least recently used entries when memory is full
   */
  private evictLeastUsed(): void {
    const entries = Array.from(this.memoryCache.entries());
    
    // Sort by last accessed time (oldest first)
    entries.sort((a, b) => {
      return a[1].lastAccessed.getTime() - b[1].lastAccessed.getTime();
    });

    // Remove oldest 10% of entries
    const toRemove = Math.ceil(entries.length * 0.1);
    
    for (let i = 0; i < toRemove; i++) {
      const [key] = entries[i];
      this.memoryCache.delete(key);
    }

    logger.info(`Cache eviction: ${toRemove} least used entries removed`);
  }

  /**
   * Monitor memory usage and log warnings
   */
  private monitorMemoryUsage(): void {
    const stats = this.getStats();
    const memoryMB = stats.memoryUsage / 1024 / 1024;
    
    if (memoryMB > 40) {
      logger.warn(`Cache memory usage high: ${memoryMB.toFixed(1)}MB`);
    }
    
    if (stats.hitRate < 50 && stats.totalHits + stats.totalMisses > 100) {
      logger.warn(`Cache hit rate low: ${stats.hitRate.toFixed(1)}%`);
    }
  }
}

// Export singleton instance
export const unifiedCache = UnifiedCacheManager.getInstance();

// Legacy compatibility exports
export const cacheService = unifiedCache;
export const getCached = <T>(key: string): T | null => unifiedCache.get<T>(key);
export const setCached = <T>(key: string, data: T, ttl?: number): void => unifiedCache.set(key, data, ttl);
export const clearCache = (): void => unifiedCache.clear();