export const TYPES = {
  FinancialDataService: Symbol.for('FinancialDataService'),
  CacheService: Symbol.for('CacheService'),
  AIAnalysisService: Symbol.for('AIAnalysisService'),
  EconomicDataService: Symbol.for('EconomicDataService'),
  SectorAnalysisService: Symbol.for('SectorAnalysisService')
};